package test

import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.SparkConf

object SparkGrep {
  def main(args: Array[String]) {

    val conf = new SparkConf().setAppName("SparkGrep");
    val sc = new SparkContext(conf)

    val fileName = "customers.txt"
    val matchTerm : String = "Jones"

    val inputFile = sc.textFile(fileName).cache()

    val matches = inputFile.filter(line => line.contains(matchTerm))

    val numMatches = matches.count()

    println("%s lines in %s contain %s".format(numMatches, fileName, matchTerm))

    sc.stop();

  }
}