package test

import java.text.SimpleDateFormat

import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.SparkConf
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.types.DateType


import scala.language.postfixOps


/*

Maven pom for eclipse/java or intellij/scala:

pom.xml

<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>
    <groupId>my.org</groupId>
    <artifactId>test4</artifactId>
    <version>1.0-SNAPSHOT</version>
    <packaging>jar</packaging>
    <dependencies>
        <dependency>
            <groupId>org.apache.spark</groupId>
            <artifactId>spark-core_2.10</artifactId>
            <version>1.5.1</version>
        </dependency>
        <dependency>
            <groupId>org.apache.spark</groupId>
            <artifactId>spark-sql_2.10</artifactId>
            <version>1.5.1</version>
        </dependency>
    </dependencies>
    <build>
        <plugins>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-compiler-plugin</artifactId>
                <version>3.1</version>
            </plugin>
        </plugins>
    </build>
</project>


Sample data:

customers.txt

100001|Joe|Smith|20150501|123 Main|75025
100002|Mary|Jones|20150502|456 South|75024


accounts.txt

200001|100001|1111.11
200002|100002|3333.33


Local spark job submit script:

submit.sh

/home/user/spark-1.5.1/bin/spark-submit \
  --class test4.SparkTest \
  --master local \
  /home/user/IdeaProjects/test/target/test4-1.0-SNAPSHOT.jar




*/

object SparkSqlDemo {

  // Java bean field definitions
  case class Person(
                     id: Int,
                     firstName: String,
                     lastName: String,
                     startDate: java.sql.Date,
                     address: String,
                     zip: String
                   )

  case class Account(
                      id: Int,
                      cid: Int,
                      balance: BigDecimal

                    )



  def main(args: Array[String]) {


    // Initialization stuff
    val conf = new SparkConf().setAppName("SparkTest");
    val sc = new SparkContext(conf)
    val sqlContext = new org.apache.spark.sql.SQLContext(sc)
    import sqlContext.implicits._


    // Input files
    val customers = sc.textFile("customers.txt")
    val accts = sc.textFile("accounts.txt")


    // Parser for customer file
    val people = customers.map(l=>l.split("\\|")).map(p => {

      var id: Int = 0
      try {
        id= p(0).trim.toInt
      } catch {
        case e: Exception => {}
      }

      val  sdf:SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
      var date: java.sql.Date = new java.sql.Date(0)
      try {
        date= new java.sql.Date(sdf.parse(p(3)).getTime)
      } catch {
        case e: Exception => {}
      }

      Person(             // to return a value from a function in scala just state the value
        id,
        p(1), p(2),
        date,
        p(4), p(5)
      )

    }

    )

    // Parser for account file
    val accounts = accts.map(l=>l.split("\\|")).map(p => {

      var id: Int = 0
      try {
        id= p(0).trim.toInt
      } catch {
        case e: Exception => {}
      }

      var cid: Int = 0
      try {
        cid= p(1).trim.toInt
      } catch {
        case e: Exception => {}
      }

      var balance: BigDecimal = BigDecimal("0.00")
      try {
        balance= BigDecimal(p(2).trim)
      } catch {
        case e: Exception => {}
      }

      Account(
        id,
        cid,
        balance
      )

    }

    )

    // Convert to dataframes and register tables with Spark SQL
    people.toDF().registerTempTable("people")
    accounts.toDF().registerTempTable("accounts")

    // Perform SQL select and join
    // Uses multi-line embedded string from Scala
    val result = sqlContext.sql(
      """
          SELECT
          *
          FROM
              people p
              JOIN accounts a on p.id=a.cid
          WHERE
              a.balance > 2000
      """).repartition(1).cache()  // for small results repartition to 1 for a single output file


    // Print results to standard out
    result.foreach(println)

    // Convert to back regular RDD with customer id and save as output file (can be to hdfs for large results)
    val out = result.map(p=>p(0))
    out.saveAsTextFile("result.txt")


    sc.stop();

  }


}

