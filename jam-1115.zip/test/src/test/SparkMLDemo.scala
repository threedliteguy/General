package test

import org.apache.log4j.{Logger,Level}
import org.apache.spark.mllib.feature.HashingTF
import org.apache.spark.mllib.regression.LabeledPoint
import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkContext, SparkConf}
import org.apache.spark.mllib.classification.{SVMModel, SVMWithSGD}
import org.apache.spark.mllib.evaluation.BinaryClassificationMetrics
import org.apache.spark.mllib.util.MLUtils
import org.apache.spark.mllib.linalg.{Vectors, Vector}


object SparkMLDemo {

  def lineToVector(s:String): Vector = {
    new HashingTF(10000).transform(s.toLowerCase().split("\\W+"))
  }

  def parseFile (s:RDD[String], label:Int): RDD[(LabeledPoint, String)] = {

    val lines: RDD[String] = s.map(_.trim).filter(_.length > 0)
    lines.map(p => (new LabeledPoint(label,lineToVector(p)), p))

  }

  def main (args: Array[String]) {

    Logger.getLogger("akka").setLevel(Level.ERROR)
    Logger.getLogger("org.apache.spark").setLevel(Level.ERROR)

    val conf = new SparkConf().setAppName("SparkMLDemo")
    val sc = new SparkContext(conf)
    sc.setCheckpointDir("checkpoints")


    val text1: RDD[String] = sc.textFile("hiawatha.txt")
    val text2: RDD[String] = sc.textFile("kalevala.txt")

    val parsedText1 = parseFile(text1, 0)
    val parsedText2 = parseFile(text2, 1)
    val data = parsedText1.union(parsedText2)


    // Split data into training (50%) and test (50%).
    val splits = data.randomSplit(Array(0.5, 0.5), seed = 11L)
    val training = splits(0).cache()
    val test = splits(1)

    // Run training algorithm to build the model
    val numIterations = 100
    val model = SVMWithSGD.train(training.map(_._1), numIterations)



    model.clearThreshold()

    // Compute scores on the test set.
    val scoresAndLabels: RDD[(Double, Double, String)] = test.map { value =>
      val score = model.predict(value._1.features)
      (score, value._1.label, value._2)
    }

    println("Low scores:")

//    scoresAndLabels.sortBy(_._1).take(10).foreach(println)

    val exclude = List("Hiawatha","Pau-Puk-Keewis","Minnehaha","Nokomis","Puggawaugun","Chibiabos","Kwasind","Iagoo","Wahonowin","Shaugodaya")

    scoresAndLabels.sortBy(_._1).filter{ p=>
      !exclude.exists( p._3.contains(_))
    }.take(10).foreach(println)

    println("High scores:")
    scoresAndLabels.sortBy(_._1, false).take(10).foreach(println)



    for (threshold <- List(0.5, 0.75, 0.8, 0.9, 1.0, 1.25, 1.5) ) {

      println()
      println("Threshold: "+threshold)

      model.setThreshold(threshold)

      // Compute predictions on the test set.
      val predicitonsAndLabels: RDD[(Double, Double)] = test.map { value =>
        val prediction = model.predict(value._1.features)
        (prediction, value._1.label)
      }

      val confusion: Array[((Double, Double), Int)] = predicitonsAndLabels.map(p => (p, 1)).reduceByKey(_ + _).collect().sortBy(p => -(p._1._1 * 2 + p._1._2))

      printConfusion(confusion)

    }

    println()
    println("Try it!")
    model.clearThreshold()
    while (true) {
      val ln = readLine()
      val prediction = model.predict(lineToVector(ln))
      println(prediction)
    }

  }

  def printConfusion(c: Array[((Double, Double), Int)]) = {
    //c.foreach(println)
    println("Confusion matrix:")
    println("                                    Condition positive           Condition negative")
    println("Predicted condition positive (1)    " + c(0)._2 + "                         " + c(1)._2)
    println("Predicted condition negative (0)    " + c(2)._2 + "                         " + c(3)._2)

  }


}
