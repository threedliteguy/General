package test



import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}
import org.http4s.dsl._
import org.http4s.server.blaze.BlazeBuilder
import org.http4s.{Request, Response}
import org.http4s.server.{HttpService, Service}

object SparkGrepServer {

  var inputFile: RDD[String] = null


  def main(args: Array[String]) {

    val port = args(0).toInt

    val conf = new SparkConf().setAppName("SparkGrep");
    val sc = new SparkContext(conf)
    sc.setCheckpointDir("checkpoints")

    val fileName = "customers.txt"

    inputFile = sc.textFile(fileName).cache()

    val service: Service[Request,Response] = HttpService {
      case req@ GET -> Root =>
        Ok(getMatches(req.params.getOrElse("q","")))
    }

    BlazeBuilder.bindHttp(port, "0.0.0.0").mountService(service,"/").run.awaitShutdown()

    sc.stop()

  }

  def getMatches(q:String):String = {
    val matches = inputFile.filter(line => line.contains(q))
    val numMatches = matches.count()
    matches.unpersist()
    "Count = " + numMatches
  }


}