/home/user/spark-1.5.1/bin/spark-submit \
  --class test4.SparkGrep \
  --master local \
  /home/user/IdeaProjects/test/target/test4-1.0-SNAPSHOT.jar
